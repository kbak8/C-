﻿
namespace CIS223_HomeworkTwo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.card1 = new System.Windows.Forms.PictureBox();
            this.card2 = new System.Windows.Forms.PictureBox();
            this.card3 = new System.Windows.Forms.PictureBox();
            this.card4 = new System.Windows.Forms.PictureBox();
            this.card5 = new System.Windows.Forms.PictureBox();
            this.card1Front = new System.Windows.Forms.PictureBox();
            this.card2Front = new System.Windows.Forms.PictureBox();
            this.card3Front = new System.Windows.Forms.PictureBox();
            this.card4Front = new System.Windows.Forms.PictureBox();
            this.card5Front = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.card1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1Front)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2Front)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3Front)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4Front)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5Front)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.Silver;
            this.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(186, 25);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(469, 39);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Click on a Card to Flip it Over";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            // 
            // lbl2
            // 
            this.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(286, 339);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(291, 41);
            this.lbl2.TabIndex = 1;
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_reset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(12, 419);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(150, 30);
            this.btn_reset.TabIndex = 2;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_exit.Location = new System.Drawing.Point(692, 419);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(150, 30);
            this.btn_exit.TabIndex = 3;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // card1
            // 
            this.card1.Image = ((System.Drawing.Image)(resources.GetObject("card1.Image")));
            this.card1.Location = new System.Drawing.Point(20, 90);
            this.card1.Name = "card1";
            this.card1.Size = new System.Drawing.Size(146, 204);
            this.card1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card1.TabIndex = 4;
            this.card1.TabStop = false;
            this.card1.Click += new System.EventHandler(this.card1_Click);
            // 
            // card2
            // 
            this.card2.Image = ((System.Drawing.Image)(resources.GetObject("card2.Image")));
            this.card2.Location = new System.Drawing.Point(186, 90);
            this.card2.Name = "card2";
            this.card2.Size = new System.Drawing.Size(146, 204);
            this.card2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card2.TabIndex = 5;
            this.card2.TabStop = false;
            this.card2.Click += new System.EventHandler(this.card2_Click);
            // 
            // card3
            // 
            this.card3.Image = ((System.Drawing.Image)(resources.GetObject("card3.Image")));
            this.card3.Location = new System.Drawing.Point(352, 90);
            this.card3.Name = "card3";
            this.card3.Size = new System.Drawing.Size(146, 204);
            this.card3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card3.TabIndex = 6;
            this.card3.TabStop = false;
            this.card3.Click += new System.EventHandler(this.card3_Click);
            // 
            // card4
            // 
            this.card4.Image = ((System.Drawing.Image)(resources.GetObject("card4.Image")));
            this.card4.Location = new System.Drawing.Point(518, 90);
            this.card4.Name = "card4";
            this.card4.Size = new System.Drawing.Size(146, 204);
            this.card4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card4.TabIndex = 7;
            this.card4.TabStop = false;
            this.card4.Click += new System.EventHandler(this.card4_Click);
            // 
            // card5
            // 
            this.card5.Image = ((System.Drawing.Image)(resources.GetObject("card5.Image")));
            this.card5.Location = new System.Drawing.Point(684, 90);
            this.card5.Name = "card5";
            this.card5.Size = new System.Drawing.Size(146, 204);
            this.card5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card5.TabIndex = 8;
            this.card5.TabStop = false;
            this.card5.Click += new System.EventHandler(this.card5_Click);
            // 
            // card1Front
            // 
            this.card1Front.Image = ((System.Drawing.Image)(resources.GetObject("card1Front.Image")));
            this.card1Front.Location = new System.Drawing.Point(20, 90);
            this.card1Front.Name = "card1Front";
            this.card1Front.Size = new System.Drawing.Size(146, 204);
            this.card1Front.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card1Front.TabIndex = 9;
            this.card1Front.TabStop = false;
            this.card1Front.Visible = false;
            this.card1Front.Click += new System.EventHandler(this.card1Front_Click);
            // 
            // card2Front
            // 
            this.card2Front.Image = ((System.Drawing.Image)(resources.GetObject("card2Front.Image")));
            this.card2Front.Location = new System.Drawing.Point(186, 90);
            this.card2Front.Name = "card2Front";
            this.card2Front.Size = new System.Drawing.Size(146, 204);
            this.card2Front.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card2Front.TabIndex = 10;
            this.card2Front.TabStop = false;
            this.card2Front.Visible = false;
            this.card2Front.Click += new System.EventHandler(this.card2Front_Click);
            // 
            // card3Front
            // 
            this.card3Front.Image = ((System.Drawing.Image)(resources.GetObject("card3Front.Image")));
            this.card3Front.Location = new System.Drawing.Point(352, 90);
            this.card3Front.Name = "card3Front";
            this.card3Front.Size = new System.Drawing.Size(146, 204);
            this.card3Front.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card3Front.TabIndex = 11;
            this.card3Front.TabStop = false;
            this.card3Front.Visible = false;
            this.card3Front.Click += new System.EventHandler(this.card3Front_Click);
            // 
            // card4Front
            // 
            this.card4Front.Image = ((System.Drawing.Image)(resources.GetObject("card4Front.Image")));
            this.card4Front.Location = new System.Drawing.Point(518, 90);
            this.card4Front.Name = "card4Front";
            this.card4Front.Size = new System.Drawing.Size(146, 204);
            this.card4Front.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card4Front.TabIndex = 12;
            this.card4Front.TabStop = false;
            this.card4Front.Visible = false;
            this.card4Front.Click += new System.EventHandler(this.card4Front_Click);
            // 
            // card5Front
            // 
            this.card5Front.Image = ((System.Drawing.Image)(resources.GetObject("card5Front.Image")));
            this.card5Front.Location = new System.Drawing.Point(684, 90);
            this.card5Front.Name = "card5Front";
            this.card5Front.Size = new System.Drawing.Size(146, 204);
            this.card5Front.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card5Front.TabIndex = 13;
            this.card5Front.TabStop = false;
            this.card5Front.Visible = false;
            this.card5Front.Click += new System.EventHandler(this.card5Front_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(854, 461);
            this.Controls.Add(this.card5Front);
            this.Controls.Add(this.card4Front);
            this.Controls.Add(this.card3Front);
            this.Controls.Add(this.card2Front);
            this.Controls.Add(this.card1Front);
            this.Controls.Add(this.card5);
            this.Controls.Add(this.card4);
            this.Controls.Add(this.card3);
            this.Controls.Add(this.card2);
            this.Controls.Add(this.card1);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Cards";
            ((System.ComponentModel.ISupportInitialize)(this.card1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1Front)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2Front)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3Front)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4Front)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5Front)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.PictureBox card1;
        private System.Windows.Forms.PictureBox card2;
        private System.Windows.Forms.PictureBox card3;
        private System.Windows.Forms.PictureBox card4;
        private System.Windows.Forms.PictureBox card5;
        private System.Windows.Forms.PictureBox card1Front;
        private System.Windows.Forms.PictureBox card2Front;
        private System.Windows.Forms.PictureBox card3Front;
        private System.Windows.Forms.PictureBox card4Front;
        private System.Windows.Forms.PictureBox card5Front;
    }
}

