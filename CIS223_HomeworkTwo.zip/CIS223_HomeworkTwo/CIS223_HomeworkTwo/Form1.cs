﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS223_HomeworkTwo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void card1_Click(object sender, EventArgs e)
        {
            lbl2.Text = "Ace of Spades";
            lbl2.ForeColor = Color.Black;
            card1.Visible = false;
            card1Front.Visible = true;
        }

        private void card2_Click(object sender, EventArgs e)
        {
            lbl2.Text = "Six of Hearts";
            lbl2.ForeColor = Color.Red;
            card2.Visible = false;
            card2Front.Visible = true;
        }

        private void card3_Click(object sender, EventArgs e)
        {
            lbl2.Text = "Six of Diamonds";
            lbl2.ForeColor = Color.Red;
            card3.Visible = false;
            card3Front.Visible = true;
        }

        private void card4_Click(object sender, EventArgs e)
        {
            lbl2.Text = "Six of Spades";
            lbl2.ForeColor = Color.Black;
            card4.Visible = false;
            card4Front.Visible = true;
        }

        private void card5_Click(object sender, EventArgs e)
        {
            lbl2.Text = "King of Spades";
            lbl2.ForeColor = Color.Black;
            card5.Visible = false;
            card5Front.Visible = true;
        }

        private void card1Front_Click(object sender, EventArgs e)
        {
            card1.Visible = true;
            card1Front.Visible = false;
            lbl2.Text = "";
        }

        private void card2Front_Click(object sender, EventArgs e)
        {
            card2.Visible = true;
            card2Front.Visible = false;
            lbl2.Text = "";
        }

        private void card3Front_Click(object sender, EventArgs e)
        {
            card3.Visible = true;
            card3Front.Visible = false;
            lbl2.Text = "";
        }

        private void card4Front_Click(object sender, EventArgs e)
        {
            card4.Visible = true;
            card4Front.Visible = false;
            lbl2.Text = "";
        }

        private void card5Front_Click(object sender, EventArgs e)
        {
            card5.Visible = true;
            card5Front.Visible = false;
            lbl2.Text = "";
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            card1.Visible = true;
            card1Front.Visible = false;
            card2.Visible = true;
            card2Front.Visible = false;
            card3.Visible = true;
            card3Front.Visible = false;
            card4.Visible = true;
            card4Front.Visible = false;
            card5.Visible = true;
            card5Front.Visible = false;
            lbl2.Text = "";
        }
    }
}
